import Icon from '@strapi/icons/Database';
import React from 'react';

const PluginIcon = () => <Icon />;

export default PluginIcon;
