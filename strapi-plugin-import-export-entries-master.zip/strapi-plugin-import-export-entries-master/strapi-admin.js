'use strict';

module.exports = require('./admin/src').default;
