export { default } from './ImportProxy';
