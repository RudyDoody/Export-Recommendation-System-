const pluginId = 'import-export-entries';

module.exports = pluginId;
