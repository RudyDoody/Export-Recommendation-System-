module.exports = ({ env }) => ({
  auth: {
    secret: 'ZMnEjgypXhdIkDmOSQ+fdQ==',
  },
  apiToken: {
    salt: 'XmXugdchV1oo4H5QnwJFSg==',
  },
});
